<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Francisco David</title>
    <style>
        a{
            display: block;
            width: fit-content;
            height: 25px;
            margin :auto;
            margin-bottom: 25px;
            padding: 15px;
            background-color: lightblue;
            color: black;
            text-decoration: none;
            border: 1px solid black;
            border-radius: 5px 20px 5px 20px
        }
        a:hover{
            background-color: lightgreen;
            color: red;
        }
    </style>
</head>
<body>
    <a href="personajes.php">Personajes</a>
    <a href="titanes.php">Titanes</a>
</body>
</html>